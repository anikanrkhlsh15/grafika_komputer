// sketch.js - MoodPop (perbaikan mirror & facemesh)
// Paste ganti file sketch.js kamu dengan ini

let video;
let mainCanvas;        // p5 canvas drawn to screen
let photoBuffer;       // offscreen graphics for clean photo capture (no overlay)
let facemesh;
let faces = [];
let isModelReady = false;
let cameraActive = false;
let gridSize = 1;      // number of cells to capture
let shots = [];        // array of captured DataURL strings
let capturing = false;
let countdownVal = 0;
let currentShotIndex = 0;
let emotes = [];
let lastExpression = 'neutral';

// UI elements (DOM)
let statusEl, galleryEl, photoListEl, countdownEl, expressionBadgeEl, shotProgressEl, downloadBtn;

// mirror default true
let mirrorMode = true;

function setup() {
  // create visible canvas and attach to DOM container
  mainCanvas = createCanvas(800, 600);
  mainCanvas.parent('canvas-container');

  // offscreen buffer sized same aspect ratio as typical webcam
  photoBuffer = createGraphics(640, 480); // fixed capture resolution

  // remove loading state visual if exists
  const loading = document.getElementById('loading-state');
  if (loading) loading.remove();

  // DOM refs
  statusEl = document.getElementById('status');
  galleryEl = document.getElementById('gallery');
  photoListEl = document.getElementById('photo-list');
  countdownEl = document.getElementById('countdown');
  expressionBadgeEl = document.getElementById('expression-badge');
  shotProgressEl = document.getElementById('shot-progress');
  downloadBtn = document.getElementById('download-btn');

  // background emojis
  createBackgroundEmojis();

  // start video capture
  startVideo();

  // hooks
  setupUIButtons();

  // mirror toggle (button)
  const mirrorBtn = document.getElementById('mirror-toggle');
  if (mirrorBtn) {
    mirrorBtn.addEventListener('click', () => {
      mirrorMode = !mirrorMode;
      if (statusEl) statusEl.textContent = mirrorMode ? "🪞 Mirror: ON" : "🪞 Mirror: OFF";
    });
  }

  // keyboard shortcut M
  document.addEventListener("keydown", (e) => {
    if (e.key && e.key.toLowerCase() === "m") {
      mirrorMode = !mirrorMode;
      if (statusEl) statusEl.textContent = mirrorMode ? "🪞 Mode Mirror: ON" : "🪞 Mode Mirror: OFF";
    }
  });

  textFont('Arial');
  textAlign(CENTER, CENTER);
}

function startVideo() {
  try {
    // createCapture returns a p5.Element video
    video = createCapture(VIDEO, () => {
      // success callback - mark active
      cameraActive = true;
      if (statusEl) statusEl.textContent = 'Kamera siap! Tersenyumlah untuk efek :)';
    });
    // Set a reasonable size for the buffer and canvas
    video.size(640, 480);
    // ensure playsinline & autoplay/muted for some browsers
    if (video.elt) {
      video.elt.setAttribute('playsinline', ''); // mobile iOS fix
      video.elt.muted = true;
      video.elt.autoplay = true;
    }
    video.hide();
    // init ml5 facemesh after small delay to ensure video frames flow
    setTimeout(initFacemesh, 600);
  } catch (err) {
    console.error('Error starting camera', err);
    showCameraError();
  }
}

function initFacemesh() {
  if (typeof ml5 === 'undefined') {
    if (statusEl) statusEl.textContent = '⚠️ ml5 tidak ditemukan — deteksi ekspresi non-aktif';
    return;
  }

  // Try to instantiate facemesh (older/newer ml5 builds might differ)
  try {
    facemesh = ml5.facemesh ? ml5.facemesh(video, { maxFaces: 1 }, () => {
      console.log('Facemesh (ml5.facemesh) loaded');
      isModelReady = true;
      if (statusEl) statusEl.textContent = 'Model siap ✅';
    }) : null;
  } catch (e) {
    console.warn('ml5.facemesh init failed:', e);
    facemesh = null;
  }

  // If facemesh exists and supports events, wire predict; otherwise try predict loop
  if (facemesh && typeof facemesh.on === 'function') {
    facemesh.on('predict', (results) => {
      faces = results || [];
      if (faces.length > 0) detectExpression(faces[0]);
    });
    facemesh.on('error', (err) => {
      console.warn('Facemesh error', err);
      if (statusEl) statusEl.textContent = '⚠️ Model deteksi bermasalah, kamera tetap jalan';
    });
  } else if (facemesh && typeof facemesh.predict === 'function') {
    // fallback: poll predictions using predict
    console.log('Facemesh: using predict() fallback');
    isModelReady = true;
    if (statusEl) statusEl.textContent = 'Model siap ✅ (fallback predict)';
    (function predictLoop(){
      facemesh.predict(video.elt ? video.elt : video, (err, results) => {
        if (!err && results) {
          faces = results;
          if (faces.length > 0) detectExpression(faces[0]);
        }
        setTimeout(predictLoop, 80); // ~12fps fallback
      });
    })();
  } else {
    console.warn('Facemesh not available with expected API.');
    if (statusEl) statusEl.textContent = '⚠️ Model facemesh tidak tersedia pada versi ml5 ini';
  }
}

function draw() {
  // background soft
  background(255, 210, 230);

  // draw video preview stretched to canvas (centered) with optional mirror
  if (cameraActive && video && video.width && video.height) {
    // letterbox to maintain aspect ratio
    let targetW = width;
    let targetH = (video.height / video.width) * targetW;
    if (targetH > height) {
      targetH = height;
      targetW = (video.width / video.height) * targetH;
    }
    const x = (width - targetW) / 2;
    const y = (height - targetH) / 2;

    // Draw preview on main canvas (apply mirror if needed)
    push();
    if (mirrorMode) {
      // flip horizontally around center of the preview area
      translate(x + targetW, 0);
      scale(-1, 1);
      image(video, 0, y, targetW, targetH);
    } else {
      image(video, x, y, targetW, targetH);
    }
    pop();

    // draw video into photoBuffer with fixed 640x480 so captures are consistent
    photoBuffer.push();
    photoBuffer.clear();
    if (mirrorMode) {
      photoBuffer.translate(photoBuffer.width, 0);
      photoBuffer.scale(-1, 1);
      photoBuffer.image(video, 0, 0, photoBuffer.width, photoBuffer.height);
    } else {
      photoBuffer.image(video, 0, 0, photoBuffer.width, photoBuffer.height);
    }
    photoBuffer.pop();

    // draw small face indicator (nose) if detected
    if (faces.length > 0 && faces[0].scaledMesh) {
      let nose = faces[0].scaledMesh[1]; // [x,y,z] in video coords (photoBuffer scale)
      if (nose) {
        // facemesh coords align with video raw size (matching our photoBuffer)
        // Map to canvas preview area for overlay indicator
        let nx = map(nose[0], 0, photoBuffer.width, x, x + targetW);
        let ny = map(nose[1], 0, photoBuffer.height, y, y + targetH);
        // if mirrorMode then mirror the overlay horizontal position to match preview flip
        if (mirrorMode) {
          // when preview flipped, mapping above already maps from left->right; but after flip on main canvas,
          // we drew the video mirrored. We need to flip nx horizontally around preview center.
          let previewCenterX = x + targetW / 2;
          nx = previewCenterX - (nx - previewCenterX);
        }
        noStroke(); fill(255,255,255,220);
        ellipse(nx, ny, 10, 10);
      }
    }
  } else {
    // show loading / instruction
    fill(214,51,132);
    textSize(20);
    text("🎀 Memuat kamera... (boleh pakai server lokal)", width/2, height/2);
  }

  // draw floating emotes using p5 text (so they overlay canvas)
  drawEmotes();

  // countdown UI handling (DOM element: we just control its visibility/text)
  if (countdownVal > 0) {
    if (countdownEl) {
      countdownEl.classList.remove('hidden');
      countdownEl.textContent = countdownVal;
    }
  } else {
    if (countdownEl) countdownEl.classList.add('hidden');
  }
}

// === Expression detection logic ===
function detectExpression(prediction) {
  if (!prediction) return;
  // ml5 facemesh result sometimes wraps differently; try to find scaledMesh
  const mesh = prediction.scaledMesh || prediction.multiFaceLandmarks || prediction; // tolerant access
  if (!mesh || !mesh.length) return;
  // if mesh is array of points, accept directly. Sometimes prediction is object with scaledMesh property that is array.
  const pts = Array.isArray(mesh[0]) ? mesh : (prediction.scaledMesh ? prediction.scaledMesh : null);
  if (!pts) return;
  // now pts is array of [x,y,z] points
  const idx = { leftEye:33, rightEye:263, nose:1, mouthLeft:61, mouthRight:291, mouthTop:13, mouthBottom:14 };
  const get = i => {
    const p = pts[i];
    return p ? { x: p[0], y: p[1], z: p[2] } : null;
  };
  let L = get(idx.leftEye), R = get(idx.rightEye), mL = get(idx.mouthLeft), mR = get(idx.mouthRight), mT = get(idx.mouthTop), mB = get(idx.mouthBottom), nose = get(idx.nose);
  if (!L || !R || !mL || !mR || !mT || !mB) return;

  // distances (these are in pixels relative to video/photoBuffer)
  let eyeDist = dist(L.x, L.y, R.x, R.y);
  let mouthW = dist(mL.x, mL.y, mR.x, mR.y);
  let mouthH = dist(mT.x, mT.y, mB.x, mB.y);
  let mouthOpen = mouthH / eyeDist;
  let mouthWidthRatio = mouthW / eyeDist;

  let exp = 'neutral';
  if (mouthOpen > 0.16 && mouthWidthRatio > 1.2) exp = 'surprised';
  else if (mouthOpen > 0.11 && mouthWidthRatio > 1.05) exp = 'smiling';
  else if (mouthOpen > 0.08 && mouthWidthRatio < 0.9) exp = 'sad';
  else if (mouthWidthRatio < 0.80 && mouthH < 0.05 * eyeDist) exp = 'angry';
  else exp = 'neutral';

  if (exp !== lastExpression) {
    lastExpression = exp;
    if (expressionBadgeEl) {
      expressionBadgeEl.textContent = (
        exp === 'smiling' ? '😊 Kamu tersenyum!' :
        exp === 'surprised' ? '😲 Terkejut!' :
        exp === 'sad' ? '😢 Sedih' :
        exp === 'angry' ? '😠 Marah' : '😐 Netral'
      );
    }
    // spawn emotes using nose coords; if mirrorMode true, pass mirrored x for nicer placement
    let nx = nose ? nose.x : photoBuffer.width/2;
    let ny = nose ? nose.y : photoBuffer.height/2;
    spawnEmotesForExpression(exp, nx, ny);
  }
}

// spawn emotes (p5 objects)
function spawnEmotesForExpression(expression, x, y) {
  let chars = [], colors = [];
  switch(expression) {
    case 'smiling':
      chars = ['❤️','😍','😊','💖','🌸']; colors = ['#FF4081','#E91E63','#F50057','#D63384','#EC4899']; break;
    case 'surprised':
      chars = ['😲','😮','💫','✨']; colors = ['#FF9800','#FF5722','#FF6B35','#FF8E53']; break;
    case 'sad':
      chars = ['😢','💧','☔']; colors = ['#2196F3','#1565C0','#0288D1']; break;
    case 'angry':
      chars = ['😠','🔥','💥']; colors = ['#F44336','#D32F2F','#C62828']; break;
    default:
      chars = ['🙂','😐','🎭']; colors = ['#9E9E9E','#757575','#90A4AE'];
  }

  for (let i=0;i<6;i++){
    emotes.push({
      char: chars[floor(random(chars.length))],
      x: map(x, 0, photoBuffer.width, 0, width) + random(-40,40),
      y: map(y, 0, photoBuffer.height, 0, height) + random(-30,30),
      size: random(18,34),
      speed: random(0.6,2.4),
      life: floor(random(70,150)),
      color: colors[floor(random(colors.length))]
    });
  }
}

function drawEmotes() {
  for (let i = emotes.length -1; i >= 0; i--) {
    let e = emotes[i];
    e.y -= e.speed;
    e.life--;
    if (e.life <= 0) emotes.splice(i,1);
    else {
      noStroke();
      textSize(e.size);
      fill(e.color);
      text(e.char, e.x, e.y);
    }
  }
}

// === UI & Capture logic ===
function setupUIButtons() {
  // grid selection buttons
  const gridButtons = document.querySelectorAll('.grid-btn');
  gridButtons.forEach(btn => {
    btn.addEventListener('click', function() {
      gridButtons.forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      gridSize = parseInt(this.getAttribute('data-grid')) || 1;
      // reset previous shots to avoid confusion
      shots = [];
      updateShotProgress();
    });
  });

  const capBtn = document.getElementById('capture-btn');
  if (capBtn) capBtn.addEventListener('click', startCaptureSequence);

  const resetBtn = document.getElementById('reset-btn');
  if (resetBtn) resetBtn.addEventListener('click', resetPhotobooth);

  if (downloadBtn) {
    downloadBtn.addEventListener('click', downloadCollage);
  }
}

function startCaptureSequence() {
  if (!cameraActive) { alert('Kamera belum aktif'); return; }
  if (capturing) return; // prevent re-entry
  capturing = true;
  shots = [];
  currentShotIndex = 0;
  updateShotProgress(true);
  // take gridSize photos sequentially with 5s countdown each
  takeNextShot();
}

function takeNextShot() {
  if (currentShotIndex >= gridSize) {
    // done capturing all shots => make collage
    capturing = false;
    updateShotProgress(false);
    createCollageFromShots();
    return;
  }
  // 5 second countdown
  countdownVal = 5;
  const interval = setInterval(() => {
    countdownVal--;
    if (countdownVal <= 0) {
      clearInterval(interval);
      countdownVal = 0;
      // capture now from photoBuffer (clean)
      // ensure photoBuffer pixels are up to date (draw already handled each frame)
      const dataURL = photoBuffer.canvas.toDataURL('image/png');
      shots.push(dataURL);
      currentShotIndex++;
      updateShotProgress();
      if (statusEl) statusEl.textContent = `Foto ${currentShotIndex} dari ${gridSize} diambil ✅`;
      // little confetti
      createConfettiEffect();
      // small delay before next shot start (0.6s)
      setTimeout(() => {
        takeNextShot();
      }, 600);
    }
  }, 1000);
}

function updateShotProgress(initial=false) {
  if (!shotProgressEl) return;
  shotProgressEl.classList.remove('hidden');
  shotProgressEl.textContent = `${currentShotIndex} / ${gridSize}`;
  if (initial) shotProgressEl.textContent = `0 / ${gridSize}`;
}

function createCollageFromShots() {
  if (!shots.length) return;
  // compute grid layout for N cells
  const cells = shots.length;
  const cols = Math.ceil(Math.sqrt(cells));
  const rows = Math.ceil(cells / cols);

  // size of collage: use photoBuffer size
  const cellW = photoBuffer.width;
  const cellH = photoBuffer.height;
  const collageW = cellW * cols;
  const collageH = cellH * rows;

  // create offscreen DOM canvas to combine images
  const collageCanvas = document.createElement('canvas');
  collageCanvas.width = collageW;
  collageCanvas.height = collageH;
  const ctx = collageCanvas.getContext('2d');

  // fill background white
  ctx.fillStyle = '#fff';
  ctx.fillRect(0,0,collageW,collageH);

  // draw each shot into grid cell
  let loadedCount = 0;
  for (let i=0;i<cells;i++){
    const img = new Image();
    img.src = shots[i];
    ((i,img)=> {
      img.onload = () => {
        const col = i % cols;
        const row = Math.floor(i / cols);
        ctx.drawImage(img, col * cellW, row * cellH, cellW, cellH);
        loadedCount++;
        // after last image loaded, show preview and enable download
        if (loadedCount === cells) {
          const finalDataURL = collageCanvas.toDataURL('image/png');
          showCollageInGallery(finalDataURL);
        }
      };
      img.onerror = (e) => {
        console.warn('Image load error for shot', i, e);
        loadedCount++;
        if (loadedCount === cells) {
          const finalDataURL = collageCanvas.toDataURL('image/png');
          showCollageInGallery(finalDataURL);
        }
      };
    })(i,img);
  }
}

function showCollageInGallery(dataURL) {
  if (galleryEl) galleryEl.classList.remove('hidden');
  const item = document.createElement('div');
  item.className = 'photo-item';
  const img = document.createElement('img');
  img.src = dataURL;
  item.appendChild(img);
  // insert at top
  if (photoListEl) photoListEl.prepend(item);
  // set for download button
  if (downloadBtn) {
    downloadBtn.href = dataURL;
    downloadBtn.dataset.img = dataURL;
    downloadBtn.classList.remove('hidden');
    downloadBtn.onclick = () => {
      const a = document.createElement('a');
      a.href = dataURL;
      a.download = `moodpop-collage-${new Date().toISOString().slice(0,19)}.png`;
      a.click();
    };
  }
  if (statusEl) statusEl.textContent = '🎉 Collage siap! Klik Unduh untuk menyimpan.';
}

function downloadCollage() {
  const data = downloadBtn ? downloadBtn.dataset.img : null;
  if (!data) { alert('Belum ada collage untuk diunduh'); return; }
  const a = document.createElement('a');
  a.href = data;
  a.download = `moodpop-collage-${new Date().toISOString().slice(0,19)}.png`;
  a.click();
}

function resetPhotobooth() {
  shots = [];
  currentShotIndex = 0;
  capturing = false;
  countdownVal = 0;
  if (document.getElementById('photo-list')) document.getElementById('photo-list').innerHTML = '';
  if (galleryEl) galleryEl.classList.add('hidden');
  if (downloadBtn) downloadBtn.classList.add('hidden');
  if (statusEl) statusEl.textContent = 'Kamera siap! Tersenyumlah :)';
  if (shotProgressEl) shotProgressEl.textContent = `0 / ${gridSize}`;
}

// small DOM confetti effect
function createConfettiEffect() {
  const emojis = ['✨','🎉','🌟','💖','🎊','💫'];
  const container = document.getElementById('canvas-container');
  if (!container) return;
  for (let i=0;i<12;i++){
    const el = document.createElement('div');
    el.className = 'emoji-decoration';
    el.textContent = emojis[Math.floor(Math.random()*emojis.length)];
    el.style.left = `${Math.random()*90+3}%`;
    el.style.top = `${Math.random()*80+10}%`;
    el.style.fontSize = `${Math.random()*18+14}px`;
    el.style.animationDelay = `${Math.random()*0.6}s`;
    container.appendChild(el);
    setTimeout(()=> el.remove(),4200);
  }
}

// camera error UI
function showCameraError() {
  const canvasContainer = document.getElementById('canvas-container');
  if (canvasContainer) {
    canvasContainer.innerHTML = `
      <div class="camera-error">
        <div style="font-size:44px; margin-bottom:10px;">📷❌</div>
        <h3>Kamera Tidak Dapat Diakses</h3>
        <p>Pastikan izin diberikan, kamera tidak dipakai aplikasi lain, dan buka lewat server lokal.</p>
        <button class="retry-button" onclick="location.reload()">🔄 Coba Lagi</button>
      </div>
    `;
  }
  if (statusEl) statusEl.textContent = '❌ Gagal akses kamera';
}

// DOM background emojis
function createBackgroundEmojis() {
  const container = document.getElementById('emoji-bg-container');
  if (!container) return;
  const emojis = ['🌸','💖','🎀','✨','🦄','💕','💫','🌟'];
  for (let i=0;i<12;i++){
    const d = document.createElement('div');
    d.className = 'emoji-bg';
    d.textContent = emojis[Math.floor(Math.random()*emojis.length)];
    d.style.left = `${Math.random()*100}%`;
    d.style.top = `${Math.random()*100}%`;
    d.style.fontSize = `${Math.random()*30+18}px`;
    d.style.opacity = (Math.random()*0.2+0.03);
    container.appendChild(d);
  }
}
